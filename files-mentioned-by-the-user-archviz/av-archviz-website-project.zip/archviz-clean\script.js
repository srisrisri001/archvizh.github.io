const sections = Array.from(document.querySelectorAll(".section"));
const dots = Array.from(document.querySelectorAll(".scroll-dot"));
const nav = document.querySelector(".site-nav");
const overlay = document.getElementById("projectOverlay");
let currentSection = 0;
let scrollCooldown = false;
let touchStartX = 0;
let touchStartY = 0;

const projects = [
  {
    key: "forest",
    edition: "Forest Edition",
    title: "Serenity Forest Villa",
    image: "assets/forest-villa.png",
    copy: "A quiet biophilic residence shaped around filtered daylight, garden edges, warm stone paths, and private family spaces that open naturally into the landscape.",
    stats: ["220 m² Plot", "4 BHK", "Garden Court"],
    colors: ["#1d4a31", "#0d1812", "rgba(106,191,122,0.22)", "#7fd58b"],
    gallery: ["Elevation", "Living Room", "Bedroom", "Kitchen", "Terrace", "Garden", "Pool", "Outdoor Dining"],
    features: [
      ["Forest deck", "A shaded outdoor lounge for slow evenings and private gatherings."],
      ["Courtyard planning", "Interior rooms borrow light and breeze from a planted core."],
      ["Natural finishes", "Timber, textured stone, and muted green details throughout."],
      ["Smart climate", "Low-energy cooling zones tuned for warm afternoons."]
    ]
  },
  {
    key: "azure",
    edition: "Azure Edition",
    title: "Azure Sky Residence",
    image: "assets/azure-residence.png",
    copy: "A crisp urban home with reflective surfaces, wide balcony lines, cool interior tones, and a light-filled plan designed for skyline views.",
    stats: ["260 m² Plot", "4.5 BHK", "Sky Terrace"],
    colors: ["#143a5d", "#081526", "rgba(90,176,224,0.22)", "#70c9f2"],
    gallery: ["Elevation", "Double Height Lounge", "Bedroom Suite", "Island Kitchen", "Sky Terrace", "Water Feature", "Pool Deck", "Study"],
    features: [
      ["Panoramic glazing", "Large openings frame city views while keeping interiors bright."],
      ["Sky lounge", "A roof terrace with lounge seating and evening lighting."],
      ["Blue stone palette", "Cool-toned finishes create a calm premium feel."],
      ["Gallery kitchen", "Open cooking and dining designed for entertaining."]
    ]
  },
  {
    key: "terra",
    edition: "Terra Edition",
    title: "Terra Cotta Manor",
    image: "assets/terra-manor.png",
    copy: "An earthy family manor with sculpted walls, shaded verandas, tactile interiors, and warm outdoor rooms suited to long weekends and relaxed hosting.",
    stats: ["200 m² Plot", "3 BHK", "Veranda Pool"],
    colors: ["#663016", "#1d0d08", "rgba(224,130,58,0.24)", "#f0a35a"],
    gallery: ["Elevation", "Living Room", "Bedroom", "Chef Kitchen", "Terrace", "Garden Court", "Pool", "Guest Suite"],
    features: [
      ["Textured facade", "Layered terracotta surfaces with deep shadow reveals."],
      ["Veranda living", "A broad transitional edge between the home and garden."],
      ["Warm interiors", "Clay, brass, linen, and deep wood accents throughout."],
      ["Private pool", "A compact pool courtyard connected to the family lounge."]
    ]
  }
];

function isMobileView() {
  return window.matchMedia("(max-width: 900px)").matches;
}

function scrollToSection(index) {
  const nextIndex = Math.max(0, Math.min(index, sections.length - 1));
  sections[nextIndex].scrollIntoView({ behavior: "smooth" });
}

function updateActiveSection(index) {
  currentSection = index;
  dots.forEach((dot, dotIndex) => dot.classList.toggle("active", dotIndex === index));
}

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    const index = sections.indexOf(entry.target);
    if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
      entry.target.classList.add("in-view");
      updateActiveSection(index);
    }
  });
}, { threshold: 0.5 });

sections.forEach((section) => observer.observe(section));

dots.forEach((dot) => {
  dot.addEventListener("click", () => scrollToSection(Number(dot.dataset.section)));
});

window.addEventListener("wheel", (event) => {
  if (overlay.classList.contains("open") || isMobileView()) return;
  event.preventDefault();
  if (scrollCooldown) return;

  scrollCooldown = true;
  scrollToSection(currentSection + (event.deltaY > 0 ? 1 : -1));
  window.setTimeout(() => {
    scrollCooldown = false;
  }, 900);
}, { passive: false });

window.addEventListener("touchstart", (event) => {
  touchStartX = event.touches[0].clientX;
  touchStartY = event.touches[0].clientY;
}, { passive: true });

window.addEventListener("touchend", (event) => {
  if (overlay.classList.contains("open") || !isMobileView()) return;

  const deltaX = touchStartX - event.changedTouches[0].clientX;
  const deltaY = touchStartY - event.changedTouches[0].clientY;

  if (Math.abs(deltaX) > 48 && Math.abs(deltaX) > Math.abs(deltaY)) {
    scrollToSection(currentSection + (deltaX > 0 ? 1 : -1));
  }
}, { passive: true });

document.querySelectorAll("[data-mobile-prev]").forEach((button) => {
  button.addEventListener("click", () => scrollToSection(currentSection - 1));
});

document.querySelectorAll("[data-mobile-next]").forEach((button) => {
  button.addEventListener("click", () => scrollToSection(currentSection + 1));
});

document.getElementById("menuToggle").addEventListener("click", () => {
  nav.classList.toggle("menu-open");
});

document.querySelectorAll("[data-nav]").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll("[data-nav]").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    nav.classList.remove("menu-open");

    if (button.dataset.nav === "residences") scrollToSection(currentSection);
    if (button.dataset.nav === "projects") openAllProjects();
    if (button.dataset.nav === "about") openInfoPage("about");
    if (button.dataset.nav === "contact") openInfoPage("contact");
  });
});

document.querySelectorAll("[data-project]").forEach((button) => {
  button.addEventListener("click", () => openProject(Number(button.dataset.project)));
});

function projectStyle(project) {
  return `--page-a:${project.colors[0]};--page-b:${project.colors[1]};--page-glow:${project.colors[2]};--page-accent:${project.colors[3]};`;
}

function tileStyle(project, index) {
  const heights = [270, 190, 235, 210, 285, 220, 250, 205];
  const mixes = [project.colors[0], project.colors[3], "#263036", "#6f563f", "#2d5d4a", "#1c2c3a", "#533722", "#324236"];
  return `--h:${heights[index % heights.length]}px;--tile-a:${mixes[index % mixes.length]};--tile-b:${project.colors[1]};`;
}

function galleryCopy(name, key) {
  const tone = key === "forest" ? "natural" : key === "azure" ? "bright" : "earthy";
  return `${name} concept with ${tone} materials, layered lighting, and client-ready architectural detailing.`;
}

function openProject(index) {
  const project = projects[index];
  overlay.innerHTML = `
    <div class="project-page" style="${projectStyle(project)}">
      <div class="overlay-topbar">
        <div class="overlay-kicker">${project.edition} / Project Detail</div>
        <button class="overlay-close" onclick="closeOverlay()">Close</button>
      </div>
      <section class="project-hero">
        <div>
          <div class="pin-kicker">Pinterest style project board</div>
          <h2 class="project-title">${project.title}</h2>
          <p class="project-copy">${project.copy}</p>
          <div class="project-stats">
            ${project.stats.map((item) => `<div class="stat-pill"><strong>${item.split(" ")[0]}</strong><span>${item.replace(item.split(" ")[0], "").trim()}</span></div>`).join("")}
          </div>
        </div>
        <div class="rotator-card">
          <div class="overlay-kicker">360 rotate image</div>
          <div class="rotator-stage"><img id="rotateImage" src="${project.image}" alt="${project.title} elevation"></div>
          <div class="rotator-controls">
            <input id="rotateRange" type="range" min="0" max="360" value="0" oninput="setRotation(this.value)">
            <button class="spin-btn" onclick="spinProject()">Rotate 360</button>
          </div>
        </div>
      </section>
      <section class="pinterest-grid">
        ${project.gallery.map((name, itemIndex) => `
          <article class="pin-card">
            <div class="pin-visual" style="${tileStyle(project, itemIndex)}">
              ${itemIndex === 0 ? `<img src="${project.image}" alt="${name}">` : ""}
            </div>
            <div class="pin-body">
              <h3>${name}</h3>
              <p>${galleryCopy(name, project.key)}</p>
            </div>
          </article>
        `).join("")}
      </section>
      <section class="feature-strip">
        ${project.features.map(([title, body]) => `<div class="feature-item"><b>${title}</b><span>${body}</span></div>`).join("")}
      </section>
    </div>`;

  openOverlay();
}

function openAllProjects() {
  overlay.innerHTML = `
    <div class="project-page">
      <div class="overlay-topbar">
        <div class="overlay-kicker">All Projects</div>
        <button class="overlay-close" onclick="closeOverlay()">Close</button>
      </div>
      <section class="pinterest-grid">
        ${projects.map((project, index) => `
          <article class="pin-card" role="button" tabindex="0" onclick="openProject(${index})">
            <div class="pin-visual" style="${tileStyle(project, index)}">
              <img src="${project.image}" alt="${project.title}">
            </div>
            <div class="pin-body">
              <h3>${project.title}</h3>
              <p>${project.edition} with gallery, 360 rotate view, and unique project features.</p>
            </div>
          </article>
        `).join("")}
      </section>
    </div>`;

  openOverlay();
}

function openInfoPage(type) {
  const isAbout = type === "about";
  overlay.innerHTML = `
    <div class="project-page">
      <div class="overlay-topbar">
        <div class="overlay-kicker">${isAbout ? "Studio Profile" : "Client Enquiry"}</div>
        <button class="overlay-close" onclick="closeOverlay()">Close</button>
      </div>
      <main class="info-page">
        <div class="info-layout">
          <section>
            <div class="pin-kicker">${isAbout ? "About Us" : "Contact"}</div>
            <h2 class="info-title">${isAbout ? "Architecture that feels calm, clear, and livable." : "Tell us about the site, the lifestyle, and the dream."}</h2>
          </section>
          <section class="${isAbout ? "info-panel" : "contact-panel"}">
            ${isAbout ? aboutMarkup() : contactMarkup()}
          </section>
        </div>
      </main>
    </div>`;

  openOverlay();
}

function aboutMarkup() {
  return `<p>AV Archviz creates immersive residential concepts for clients who want to understand a home before it is built. We combine exterior visualization, interior mood direction, spatial storytelling, and premium presentation design so every project feels easy to imagine and confident to approve.</p>`;
}

function contactMarkup() {
  return `
    <p>Share your preferred edition, site size, city, budget range, and the rooms you want prioritized. Our team can prepare a project walkthrough, image gallery, feature list, and visual direction for your villa or residence.</p>
    <div class="contact-grid">
      <div class="contact-row"><span>Email</span><strong>studio@avarchviz.com</strong></div>
      <div class="contact-row"><span>Phone</span><strong>+91 98765 43210</strong></div>
      <div class="contact-row"><span>Visit</span><strong>Chennai Design District</strong></div>
    </div>`;
}

function openOverlay() {
  overlay.classList.add("open");
  overlay.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
}

function closeOverlay() {
  overlay.classList.remove("open");
  overlay.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}

function setRotation(value) {
  const image = document.getElementById("rotateImage");
  if (image) image.style.setProperty("--spin", `${value}deg`);
}

function spinProject() {
  const range = document.getElementById("rotateRange");
  if (!range) return;

  let step = 0;
  const start = Number(range.value) || 0;
  const timer = window.setInterval(() => {
    step += 12;
    const value = (start + step) % 361;
    range.value = value;
    setRotation(value);
    if (step >= 360) window.clearInterval(timer);
  }, 28);
}

const likeKey = "archvizLikeCount";
const likedKey = "archvizLiked";
const likeCount = document.getElementById("likeCount");
const globalHeart = document.getElementById("globalHeart");

function renderLikes() {
  likeCount.textContent = localStorage.getItem(likeKey) || "0";
  globalHeart.classList.toggle("liked", localStorage.getItem(likedKey) === "1");
}

globalHeart.addEventListener("click", () => {
  const liked = localStorage.getItem(likedKey) === "1";
  let count = Number(localStorage.getItem(likeKey) || "0");

  count = liked ? Math.max(0, count - 1) : count + 1;
  localStorage.setItem(likeKey, String(count));
  localStorage.setItem(likedKey, liked ? "0" : "1");
  renderLikes();
});

renderLikes();
